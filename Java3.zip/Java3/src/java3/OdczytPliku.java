package java3;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class OdczytPliku {
    public static void main(String[] args) {
        String napis="ala ma kota";
        String[] tabNapisow = napis.split(" ");
        for(String s : tabNapisow)
        {
            System.out.println(s);
        }
        
        try {
            Scanner sc=new Scanner(new File("plik.txt"));
            
            while(sc.hasNextLine())
                System.out.println(sc.nextLine());
            
            
            
        } catch (FileNotFoundException ex) {
            System.out.println("Problem z odczytem");
        }
    }
}
