package java3;

import static java.lang.Math.sqrt;
import java.util.InputMismatchException;
import java.util.Scanner;

public class Kalkulator {
    
    public static double obetnij(double l)
    {
        return Math.floor(l*100)/100.0;
    }
 
    public static void main(String[] args) {
        
        try{
        System.out.println("Hello");
        Scanner sc = new Scanner(System.in); //dodaje java.util
       // String odczyt = sc.next(); //metoda next czyta do pierwszej spacji NextLine
        //System.out.print("Przedstaw sie: ");
       //String odczyt1= sc.nextLine();
       // System.out.println(odczyt);
       // System.out.println(odczyt1);
        System.out.println("-------------Kalkulator-----------");
        System.out.println("Podaj pierwszą liczbę: ");
        int liczba1=sc.nextInt();
         System.out.println("Podaj drugą liczbę: ");
        int liczba2=sc.nextInt();
        System.out.println("Suma liczb " + liczba1 + " i " + liczba2 + " wynosi " + (liczba1+liczba2));
        System.out.println("Różnica liczb " + liczba1 + " i " + liczba2 + " wynosi " + (liczba1-liczba2));
        System.out.println("Iloczyn liczb " + liczba1 + " i " + liczba2 + " wynosi " + (liczba1*liczba2));
        if(liczba2==0)
        {
            System.out.println("Nie można dzielić przez zero --> błędny iloraz");
        }
        else
        {   
            System.out.println("Iloraz liczb " + liczba1 + " i " + liczba2 + " wynosi " + obetnij((double)liczba1/liczba2));
        }
        
        System.out.println("Srednia arytmetyczna liczb " + liczba1 + " i " + liczba2 + " wynosi " + obetnij((liczba1+liczba2)/2.0));
        if(liczba1>=0 && liczba2>=0)
        {
            System.out.println("Średnia geometryczna liczb " + liczba1 + " i " + liczba2 + " wynosi " + obetnij(sqrt(liczba1*liczba2)));
        }
        else
        {
            System.out.println("Jedna lub dwie liczby są mniejsze od zera, srednia geometryczna nie istnieje");
        }
        
        sc.close();
        }
        catch(InputMismatchException e){
            System.out.println("Błędnie podana liczba");}
    }
    
}
