package powtorzenie;

import static java.lang.Math.sqrt;

public class Punkt2D
{
    private int x;
    private int y;
    
    public Punkt2D(int x, int y)
    {
        this.x = x;
        this.y = y;
    }
    
    public int GetX()
    {
        return x;
    }
    
    public int GetY()
    {
        return y;
    }
    
    public void SetX(int x)
    {
        this.x = x;
    }
    
    public void SetY(int y)
    {
        this.y = y;
    }

    @Override
    public String toString()
    {
        return "(" + x + ", " + y + ")";
    }
    
    public void Dodawanie(Punkt2D p)
    {
        x += p.GetX();
        y += p.GetY();
    }
    
    public void Iloczyn(int liczba)
    {
        x *= liczba;
        y *= liczba;
    }
    
    public double OdlegloscOdZera()
    {
        return sqrt((0 - x) * (0 - x) + (0 - y) * (0 - y));
    }
    
    
    
}
