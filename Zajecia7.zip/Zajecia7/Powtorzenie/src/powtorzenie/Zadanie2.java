package powtorzenie;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Zadanie2 
{
    public static void main(String[] args)
    {
        int number1, number2;
        Scanner reader = new Scanner(System.in);        
        System.out.println("Podaj pierwsza liczbe");
        number1 = reader.nextInt();
        System.out.println("Podaj druga liczbe");
        number2 = reader.nextInt();
        reader.close();
        
        int min, max;        
        if (number1 < number2)
        {
            min = number1;
            max = number2;
        }
        else
        {
            min = number2;
            max = number1;
        }
        
        ZapiszLiczbyPierwsze(min, max);
    }
    
    private static void ZapiszLiczbyPierwsze(int min, int max)
    {
        try
        {
            PrintWriter writer = new PrintWriter(new File("LiczbyPierwsze.txt"));
        
            for(int i = min; i < max; i++)
            {
                int dzielniki = 0;
                for(int j = 1; j <= i; j++)
                {
                    if (i % j == 0)
                    {
                        dzielniki += 1;
                    }
                }
                if (dzielniki == 2)
                {
                    String tmp = String.valueOf(i);
                    
                    System.out.println(tmp);
                    char last = tmp.charAt(tmp.length() - 1);
                    if (last == '1')
                    {
                        
                        writer.println(tmp);
                    }
                }
            }
            writer.close();
        }
        catch (FileNotFoundException ex)
        {
            Logger.getLogger(Zadanie2.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        
    }
}
