package powtorzenie;

import javax.swing.JOptionPane;

public class Test
{
    public static void main(String[] args)
    {

        int[] numbers = new int[6];
        numbers[0] = Integer.parseInt(JOptionPane.showInputDialog("Input <1st Integer>"));
        numbers[1] = Integer.parseInt(JOptionPane.showInputDialog("Input <2nd Integer>"));
        numbers[2] = Integer.parseInt(JOptionPane.showInputDialog("Input <3rd Integer>"));
        numbers[3] = Integer.parseInt(JOptionPane.showInputDialog("Input <4th Integer>"));
        numbers[4] = Integer.parseInt(JOptionPane.showInputDialog("Input <5th Integer>"));
        numbers[5] = Integer.parseInt(JOptionPane.showInputDialog("Input <6th Integer>"));
        
        Punkt2D p1 = new Punkt2D(numbers[0], numbers[1]);
        Punkt2D p2 = new Punkt2D(numbers[2], numbers[3]);
        Punkt2D p3 = new Punkt2D(numbers[4], numbers[5]);
        
        p1.Iloczyn(2);
        p2.Iloczyn(-3);
        p1.Dodawanie(p2);
        System.out.println("2*p1 - 3*p2 = " + p1.toString());
        System.out.println("Odleglosc punktu " + p3.toString() + " od punktu " + new Punkt2D(0, 0) + " wynosi: " + p3.OdlegloscOdZera());
        
    }
}
