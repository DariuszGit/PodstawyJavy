package powtorzenie;

public class Powtorzenie
{
    public static void main(String[] args)
    {
        // TODO code application logic here
    }
    
}
