package java8;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.Statement;

public class BazaDanych
{
    public static void main(String[] args) throws Exception
    {
        Class.forName("com.mysql.jdbc.Driver"); 
        String url = "jdbc:mysql://localhost:3306/osoby";
        String login = "root";
	String password = "";
	Connection conn = DriverManager.getConnection(url ,login, password);
        
        Statement st = conn.createStatement();
	ResultSet rs = st.executeQuery("SELECT * FROM studenci");
        ResultSetMetaData rsmd = rs.getMetaData();

        //System.out.println("id\timie\tnazwisko\twiek");
        for(int i = 1; i <= rsmd.getColumnCount(); i++)
        {
            System.out.print(rsmd.getColumnName(i) +"\t");                
        }
        System.out.println("");
        while(rs.next())
        {
            for(int i = 1; i <= rsmd.getColumnCount(); i++)
            {
                System.out.print(rs.getString(i) + "\t");
            }
            System.out.println("");

           //System.out.println(rs.getString(1) + " " + rs.getString(2) + " " + rs.getString(3) + " " + rs.getString(4)); 
        }
        
        //st.executeUpdate("CREATE TABLE przedmioty(przedmiot VARCHAR(20),semestr INT)");
        //st.executeUpdate("INSERT INTO przedmioty VALUES ('matematyka','2')");
        st.executeUpdate("INSERT INTO przedmioty VALUES ('fizyka','3')");
        st.executeUpdate("INSERT INTO przedmioty VALUES ('angielski','3')");
        
        DatabaseMetaData daneBazy = conn.getMetaData();
        rs.close();
        st.close();
        conn.close();

    }    
}
