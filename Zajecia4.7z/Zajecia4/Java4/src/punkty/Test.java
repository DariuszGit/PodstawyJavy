package punkty;

import java.util.Random;

public class Test
{    
    public static void main(String[] args)
    {
        Punkt2D p1 = new Punkt2D(5, 8);
        Punkt2D p2 = new Punkt2D(3, 6);
        
        System.out.println(p1);
        System.out.println(p2);
        System.out.println("Liczba wspolrzednych punktu p1: " + p1.LiczbaWspolrzednych());
        System.out.println("Liczba wspolrzednych punktu p2: " + p2.LiczbaWspolrzednych());
        
        p1.setX(10);
        System.out.println(p1);
        
        Punkt3D t1 = new Punkt3D(1, 2, 3);
        System.out.println(t1);
        System.out.println("Liczba wspolrzednych punktu t1: " + t1.LiczbaWspolrzednych());
        
        Random generator = new Random();
        double liczba = generator.nextDouble();
        Punkt2D p;
        if (liczba < 0.5)
        {
            p = new Punkt2D(1, 2);
        }
        else
        {
            p = new Punkt3D(1, 2, 3);
        }
        System.out.println(p);
        System.out.println("Liczba wspolrzednych punktu p: " + p.LiczbaWspolrzednych());
        
        //pd cwiczenie 4 i 5
    }
}
