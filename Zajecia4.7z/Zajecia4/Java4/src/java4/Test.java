package java4;

public class Test
{
    public static void main(String[] args)
    {
        Samochod sam1 = new Samochod();
        System.out.println(sam1.getDlugosc());
        System.out.println(sam1.getSzerokosc());
        System.out.println(sam1.getPredkoscJazdy());
        
        sam1.setDlugosc(4000);
        sam1.setSzerokosc(250);
        sam1.setPredkoscJazdy(300);
        sam1.setMarka("Toyota");
        
        System.out.println(sam1.getDlugosc());
        System.out.println(sam1.getSzerokosc());
        System.out.println(sam1.getPredkoscJazdy());
        
        Samochod sam2 = new Samochod();
        
        sam2.setDlugosc(4500);
        sam2.setSzerokosc(450);
        sam2.setPredkoscJazdy(220);
        sam2.setMarka("Opel");
        
        System.out.println(sam2.getDlugosc());
        System.out.println(sam2.getSzerokosc());
        System.out.println(sam2.getPredkoscJazdy());
        
        Samochod sam3 = new Samochod("Lamborghini", 5000, 2300, 250);
        
        System.out.println("Samochod1");
        System.out.println(sam1);
        System.out.println("Samochod2");
        System.out.println(sam2);
        System.out.println("Samochod3");
        System.out.println(sam3);
    }
    
}
