package java4;

public class Samochod
{
    int dlugosc;
    int szerokosc;
    int predkoscJazdy;
    String marka;

    public Samochod()
    {
        
    }
    
    public Samochod(String marka, int dlugosc, int szerokosc, int predkoscJazdy)
    {
        this.marka = marka;
        this.dlugosc = dlugosc;
        this.szerokosc = szerokosc;
        this.predkoscJazdy = predkoscJazdy;
    }  

    public int getDlugosc()
    {
        return dlugosc;
    }

    public int getSzerokosc() 
    {
        return szerokosc;
    }

    public int getPredkoscJazdy() 
    {
        return predkoscJazdy;
    }

    public String getMarka() {
        return marka;
    }    

    public void setDlugosc(int dlugosc) 
    {
        this.dlugosc = dlugosc;
    }
    
    public void setSzerokosc(int szerokosc)
    {
        this.szerokosc = szerokosc;
    }
    public void setPredkoscJazdy(int predkoscJazdy) 
    {
        this.predkoscJazdy = predkoscJazdy;
    } 

    public void setMarka(String marka)
    {
        this.marka = marka;
    }    

    @Override
    public String toString()
    {
        return "Marka: " + getMarka() + " Dlugosc: " +  getDlugosc() + " Szerokosc: " + getSzerokosc() + " Predkosc: " + getPredkoscJazdy();      
    }
    
    


    
    
    
}
