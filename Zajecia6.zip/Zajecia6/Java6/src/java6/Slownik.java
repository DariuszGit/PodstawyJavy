package java6;

import java.util.HashMap;

public class Slownik
{
    public static void main(String[] args)
    {
        HashMap<Character,String> slownik = new HashMap<Character, String>();
        slownik.put('-', "minus");
        slownik.put('0',"zero");
        slownik.put('1',"jeden");
        slownik.put('2',"dwa");
        slownik.put('3',"trzy");
        slownik.put('4',"cztery");
        slownik.put('5',"piec");
        slownik.put('6',"szesc");
        slownik.put('7',"siedem");
        slownik.put('8',"osiem");
        slownik.put('9',"dziewiec");
        double kwota = -234.32;
        String kwotas = kwota+"";
        String[] tab = kwotas.split("[.]");
        for(char c : tab[0].toCharArray())
            System.out.print("*"+slownik.get(c));
        System.out.println("*"+tab[1]+"/100 zl"); 
    }
}
