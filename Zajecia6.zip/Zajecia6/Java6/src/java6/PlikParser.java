package java6;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

public class PlikParser {

    public static void main(String[] args)
    {
        try 
        {
            Scanner reader = new Scanner(new File("dane.txt"));
            PrintWriter writer = new PrintWriter(new File("wynik.txt"));
            
            int counter = 0;
            
            while (reader.hasNext())
            {
                String word = reader.next();
                //String[] wordsTable = word.split("[,.?!()]");
                //System.out.println(++counter + " " + wordsTable[0]);
                word = word.replaceAll("[,.?!()]", "");
                System.out.println(++counter + " " + word);                 
                
                if(reader.hasNext())
                {
                   writer.println(word);
                }
                else 
                {
                    writer.print(word);
                }                
            }
            
            writer.flush();
            writer.close();
            reader.close();
            
        } 
        catch (FileNotFoundException ex)
        {
            System.out.println("Problem z plikiem");
        }
    }
    
}
