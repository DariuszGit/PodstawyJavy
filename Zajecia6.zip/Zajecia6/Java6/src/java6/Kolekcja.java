package java6;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Kolekcja
{
    public static void main(String[] args)
    {
        try {
            /*HashSet<String> zbior = new HashSet<String>();
            
            zbior.add("Ala");
            zbior.add("ma");
            zbior.add("kota.");
            
            Iterator it = zbior.iterator();
            
            while (it.hasNext())
            {
            System.out.println(it.next());
            }
            
            Object[] tabObj = zbior.toArray();
            
            for(int i = 0; i < tabObj.length; i++)
            {
            Object obj = tabObj[i];
            System.out.println(obj);
            }
            
            for(Object o : tabObj)
            {
            System.out.println(o);
            }
            */
            ////////////////////////////////////////
            
            Scanner reader = new Scanner(new File("wynik.txt"));
            int counter = 0;
            HashSet<String> zbior = new HashSet<String>();
            
            while (reader.hasNext())
            {
                zbior.add((reader.next()));                
            }
            Iterator it = zbior.iterator();
            
            for(Object s : zbior.toArray())
            {
                System.out.println(s);
            }
            System.out.println("Ilosc wyrazow: " + zbior.size());    
            
            
            PrintWriter writer = new PrintWriter(new File("wynik2.txt"));
            while(it.hasNext())
            {
                writer.println(it.next());
            }
            writer.flush();
            writer.close();
            reader.close();
        }  
        catch (FileNotFoundException ex)
        {
            System.out.println("Problem z plikiem");
        }
    }
}
