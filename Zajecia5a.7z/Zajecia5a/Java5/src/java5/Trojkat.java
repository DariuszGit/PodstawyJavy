package java5;

import java.util.Scanner;

public class Trojkat
{
    
    public static boolean czyTrojkat(Punkt2D p1, Punkt2D p2, Punkt2D p3)
    {
        double bokA = p1.odelgloscOdPunktu(p2);
        double bokB = p2.odelgloscOdPunktu(p3);
        double bokC = p3.odelgloscOdPunktu(p1);
        
        if (bokA + bokB > bokC && bokA + bokC > bokB && bokB + bokC > bokA)
        {
            return true;
        }
        else
        {
            return false;
        }
    }
    
    public static double poleTrojkata(Punkt2D p1, Punkt2D p2, Punkt2D p3)
    {
        if (czyTrojkat(p1, p2, p3))
        {
            double bokA = p1.odelgloscOdPunktu(p2);
            double bokB = p2.odelgloscOdPunktu(p3);
            double bokC = p3.odelgloscOdPunktu(p1);
            
            double p = (bokA + bokB + bokC) / 2;
            
            return Math.sqrt(p * (p - bokA) * (p - bokB) * (p - bokC));
        }
        
        return 0;
    }
    
    public static void main(String[] args)
    {
        Punkt2D p1 = new Punkt2D(0,0);
        Punkt2D p2 = new Punkt2D(0,5);
        Punkt2D p3 = new Punkt2D(5,0);
        
        //System.out.println(p1.odelgloscOdPunktu(p2));
        //System.out.println(p2.odelgloscOdPunktu(p1));
        
        //wczytujemy do uzytkownika wspolrzedne 3 punktow i sprawdzamy czy tworza trojkat,
        //a jesli tak to wyznaczamy jego pole
        
        System.out.println(poleTrojkata(p1, p2, p3));
        
        Scanner scan = new Scanner(System.in);
        System.out.println("Podaj x1");
        int x = scan.nextInt();
        System.out.println("Podaj y1");
        int y =  scan.nextInt();
        
        p1 = new Punkt2D(x, y);
        
        System.out.println("Podaj x2");
        x = scan.nextInt();
        System.out.println("Podaj y2");
        y =  scan.nextInt();
        p2 = new Punkt2D(x, y);
         
        System.out.println("Podaj x3");
        x = scan.nextInt();
        System.out.println("Podaj y3");
        y =  scan.nextInt();
        p3 = new Punkt2D(x, y);
        
        System.out.print("Pole trojkata wynosi: ");
        System.out.println(poleTrojkata(p1, p2, p3));
    }    
}
