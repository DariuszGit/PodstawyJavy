package java4;

public class Test {

    public static void main(String[] args) {
       
        
        Samochod sam1 = new Samochod();
        
        System.out.println(sam1.getDlugosc());
        System.out.println(sam1.getSzerokosc());
        System.out.println(sam1.getPredkoscJazdy());
        
        sam1.setDlugosc(4400);
        sam1.setSzerokosc(2600);
        sam1.setPredkoscJazdy(230);
        
        System.out.println(sam1.getDlugosc());
        System.out.println(sam1.getSzerokosc());
        System.out.println(sam1.getPredkoscJazdy()); 
        
        Samochod sam2 = new Samochod();
        
        System.out.println(sam2.getDlugosc());
        System.out.println(sam2.getSzerokosc());
        System.out.println(sam2.getPredkoscJazdy());
        
        sam2.setDlugosc(4200);
        sam2.setSzerokosc(2200);
        sam2.setPredkoscJazdy(180);
        
        System.out.println(sam2.getDlugosc());
        System.out.println(sam2.getSzerokosc());
        System.out.println(sam2.getPredkoscJazdy());

        System.out.println("sam1: "+sam1);
        System.out.println("sam2: "+sam2);       
        
        Samochod sam3 = new Samochod(3800,1900,130);
        
        System.out.println(sam3.getDlugosc());
        System.out.println(sam3.getSzerokosc());
        System.out.println(sam3.getPredkoscJazdy());    
        
        System.out.println("sam3: "+sam3);
        
    }
    
}
