package punkty;

import java.util.Random;

public class Test {
    
    public static void main(String[] args) {
        
        Punkt2D p1 = new Punkt2D(1,2);
        Punkt2D p2 = new Punkt2D(3,4);
        
        System.out.println(p1);
        System.out.println(p2);
        
        System.out.println("liczba wspol. punktu p1: "+p1.liczbaWspolrzednych());
        System.out.println("liczba wspol. punktu p1: "+p2.liczbaWspolrzednych());
        
        //p1.setX(10);
       // p1.x=10;
        
       // System.out.println(p1.x);
       
        //p1.setX(-10);
        
        //System.out.println(p1);
       
        
         //System.out.println(p1);
         
        Punkt3D t1 = new Punkt3D(1,2,3);
        
        System.out.println(t1);
        
        System.out.println("liczba wspol. punktu t1: "+t1.liczbaWspolrzednych());
        
        Random generator = new Random();
        
        double liczba = generator.nextDouble();
        
        Punkt2D p;
        
        if (liczba < 0.5)
            p = new Punkt2D(1,2);
        else    
            p = new Punkt3D(1,2,3);
        
        System.out.println(p);

        System.out.println(p.liczbaWspolrzednych());        
        
    }
    
    
}
