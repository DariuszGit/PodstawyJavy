package java9;

import javax.swing.JFrame;

public class Okienko extends JFrame
{
    public Okienko()
    {
        super();
        setSize(400, 200);
        setLocation(200, 200);
    }
    public static void main(String[] args)
    {
        Okienko ok = new Okienko();
        ok.setVisible(true);
        ok.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }    
}
