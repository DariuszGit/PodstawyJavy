package java9;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.TextArea;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JRadioButtonMenuItem;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.KeyStroke;
import javax.swing.UIManager;

public class Notatnik extends JFrame implements ActionListener
{
        private TextArea textArea;
	public Notatnik()
        {

		setTitle("Notatnik");

		Toolkit zestaw = Toolkit.getDefaultToolkit();
		Dimension rozmiarEkranu = zestaw.getScreenSize();
		int szerEkranu = rozmiarEkranu.width;
		int wysEkranu = rozmiarEkranu.height;
		setBounds(szerEkranu/4,wysEkranu/4,szerEkranu/2,wysEkranu/2);

		setResizable(false);
                JMenuBar pasekMenu = new JMenuBar();
                JMenu mPlik = new JMenu("Plik");
                JMenu mEdycja = new JMenu("Edycja");
                JMenu mPomoc = new JMenu("Pomoc");
                
                pasekMenu.add(mPlik);
                pasekMenu.add(mEdycja);
                pasekMenu.add(mPomoc);
                
                setJMenuBar(pasekMenu);
                
                JMenuItem otworz = new JMenuItem("Otwórz");
                JMenuItem zapisz = new JMenuItem("Zapisz");
                JMenuItem zakoncz = new JMenuItem("Zakończ");
                mPlik.add(otworz);
                mPlik.add(zapisz);
                mPlik.addSeparator();
                mPlik.add(zakoncz);
                mPlik.setToolTipText("Opcje pliku");
                
                JRadioButtonMenuItem powiekszC = new JRadioButtonMenuItem("powiekszCzcionke");
                JRadioButtonMenuItem pomniejszC = new JRadioButtonMenuItem("pomniejszCzcionke", true);
                
                ButtonGroup groupBox = new ButtonGroup();
                groupBox.add(powiekszC);
                groupBox.add(pomniejszC);
                JMenuItem wyczysc = new JMenuItem("Wyczyść");
                mEdycja.add(powiekszC);
                mEdycja.add(pomniejszC);
                mEdycja.addSeparator();
                mEdycja.add(wyczysc);                
                mEdycja.setToolTipText("Opcje edycji");
                
                JMenuItem autor = new JMenuItem("O Autorze");
                mPomoc.add(autor);
                mPomoc.setToolTipText("Opcje pomocy");
                
            otworz.setAccelerator(KeyStroke.getKeyStroke("ctrl O"));
            zapisz.setAccelerator(KeyStroke.getKeyStroke("ctrl S"));
            zakoncz.setAccelerator(KeyStroke.getKeyStroke("ctrl K"));
            wyczysc.setAccelerator(KeyStroke.getKeyStroke("ctrl D"));
                
            mPlik.setMnemonic('P');
            mEdycja.setMnemonic('E');
            mPomoc.setMnemonic('O');
                
            JTextArea textArea = new JTextArea();
            JScrollPane sp = new JScrollPane(textArea,JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
            setLayout(new BorderLayout());
            add(sp,BorderLayout.CENTER);
                
            JPanel panelLewy = new JPanel(new FlowLayout(FlowLayout.CENTER));
            JPanel panelPrawy = new JPanel(new FlowLayout(FlowLayout.CENTER));
            JPanel panelPrzyciski = new JPanel(new GridLayout(1,2));
            panelPrzyciski.add(panelLewy);
            panelPrzyciski.add(panelPrawy);	
            add(panelPrzyciski,BorderLayout.SOUTH);
                
            JButton tytul = new JButton("tytuł");
            JButton podpis = new JButton("podpis");
            panelLewy.add(tytul);
            panelLewy.add(podpis);	
                
                
            JRadioButton bi = new JRadioButton("biały",true);
            JRadioButton zo = new JRadioButton("żółty");
            JRadioButton zi = new JRadioButton("zielony");

            ButtonGroup bg1 = new ButtonGroup();
        
            bg1.add(bi);
            bg1.add(zo);
            bg1.add(zi);
        
            panelPrawy.add(bi);
            panelPrawy.add(zo);
            panelPrawy.add(zi);
            
            bi.addActionListener(this);
            zo.addActionListener(this);
            zi.addActionListener(this);
            
            bi.setActionCommand("51");
            zo.setActionCommand("52");
            zi.setActionCommand("53");
	}

	public static void main(String[] args) throws Exception
        {
            UIManager.setLookAndFeel("com.sun.java.swing.plaf.windows.WindowsLookAndFeel");
            Notatnik nt = new Notatnik();
            nt.setVisible(true);
            nt.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            ImageIcon img = new ImageIcon("notepad.png");
            nt.setIconImage(img.getImage());
	}

    @Override
    public void actionPerformed(ActionEvent e)
    {        
        		//sprawdzenie ktory przycisk zostal wcisniety i wykonanie odpowiedniej akcji
		switch (Integer.parseInt(e.getActionCommand()))
		{
			case 11:
			{
				break;
			}
			case 12:
			{
				break;
			}
			case 13:
			{
				break;
			}
			case 21:
			{
				break;
			}
			case 22:
			{
				break;
			}
			case 23:
			{
				break;
			}
			case 31:
			{
				break;
			}
			case 41:
			{
				break;
			}		
			case 42:
			{
				break;
			}			
			case 51:
			{
				textArea.setBackground(Color.WHITE);
				break;
			}
			case 52:
			{
				textArea.setBackground(Color.YELLOW);
				break;
			}
			case 53:
			{
				textArea.setBackground(Color.GREEN);
				break;
			}
		}
    }
}
